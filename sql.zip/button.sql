/*
Navicat MySQL Data Transfer

Source Server         : leufay
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-04 18:26:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for button
-- ----------------------------
DROP TABLE IF EXISTS `button`;
CREATE TABLE `button` (
  `BUTTON_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `MENU_ID` bigint(20) DEFAULT NULL,
  `BUTTON_NAME` varchar(100) DEFAULT NULL,
  `BUTTON_URL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BUTTON_ID`),
  KEY `FK_Reference_9` (`MENU_ID`),
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`MENU_ID`) REFERENCES `menu` (`MENU_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of button
-- ----------------------------
INSERT INTO `button` VALUES ('1', '1', '增加', 'add');
INSERT INTO `button` VALUES ('2', '1', '删除', 'del');
INSERT INTO `button` VALUES ('3', '1', '修改', 'update');
INSERT INTO `button` VALUES ('4', '1', '查看', 'view');
INSERT INTO `button` VALUES ('5', '2', '增加', 'add');
INSERT INTO `button` VALUES ('6', '2', '删除', 'del');
INSERT INTO `button` VALUES ('7', '2', '修改', 'update');
INSERT INTO `button` VALUES ('8', '2', '查看', 'view');
INSERT INTO `button` VALUES ('9', '3', '增加', 'add');
INSERT INTO `button` VALUES ('10', '3', '删除', 'del');
INSERT INTO `button` VALUES ('11', '3', '修改', 'update');
INSERT INTO `button` VALUES ('12', '3', '查看', 'view');
INSERT INTO `button` VALUES ('13', '1', '分配角色', 'setRole');
INSERT INTO `button` VALUES ('14', '2', '分配权限', 'setPerm');
INSERT INTO `button` VALUES ('15', '3', '设置资源', 'setResource');
