/*
Navicat MySQL Data Transfer

Source Server         : leufay
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-04 18:27:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `MENU_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `MOD_ID` bigint(20) DEFAULT NULL,
  `MENU_NAME` varchar(20) DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`),
  KEY `FK_Reference_10` (`MOD_ID`),
  CONSTRAINT `FK_Reference_10` FOREIGN KEY (`MOD_ID`) REFERENCES `module` (`mod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '3', '用户管理', 'user');
INSERT INTO `menu` VALUES ('2', '3', '角色管理', 'role');
INSERT INTO `menu` VALUES ('3', '3', '权限管理', 'perm');
INSERT INTO `menu` VALUES ('4', '3', '资源管理', 'resource');
INSERT INTO `menu` VALUES ('5', '4', '个人资料', null);
INSERT INTO `menu` VALUES ('6', '4', '密码修改', null);
