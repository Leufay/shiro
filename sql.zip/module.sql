/*
Navicat MySQL Data Transfer

Source Server         : leufay
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-04 18:27:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for module
-- ----------------------------
DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `mod_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `PERM_ID` bigint(20) DEFAULT NULL,
  `MOD_NAME` varchar(20) DEFAULT NULL,
  `mod_url` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`mod_id`),
  KEY `FK_Reference_11` (`PERM_ID`),
  CONSTRAINT `FK_Reference_11` FOREIGN KEY (`PERM_ID`) REFERENCES `perm` (`PERM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of module
-- ----------------------------
INSERT INTO `module` VALUES ('1', null, '流程管理', 'flow');
INSERT INTO `module` VALUES ('2', null, '公司行政', 'company');
INSERT INTO `module` VALUES ('3', null, '系统管理', 'system');
INSERT INTO `module` VALUES ('4', null, '个人设置', 'personal');
