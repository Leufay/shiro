/*
Navicat MySQL Data Transfer

Source Server         : leufay
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-04 18:27:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for perm
-- ----------------------------
DROP TABLE IF EXISTS `perm`;
CREATE TABLE `perm` (
  `PERM_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PERM_NAME` varchar(20) DEFAULT NULL,
  `PERM_TYPE` varchar(20) DEFAULT NULL,
  `perm_no` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`PERM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of perm
-- ----------------------------
INSERT INTO `perm` VALUES ('7', '用户管理权限', null, 'system:user:add,system:user:del,system:user:update,system:user:view,system:user:setRole');
INSERT INTO `perm` VALUES ('11', '角色管理权限', null, 'system:role:add,system:role:del,system:role:update,system:role:view,system:role:setPerm');
INSERT INTO `perm` VALUES ('12', '权限管理权限', null, 'system:perm:add,system:perm:del,system:perm:update,system:perm:view,system:perm:setResource');
INSERT INTO `perm` VALUES ('13', '用户列表权限', null, 'system:user:view');
INSERT INTO `perm` VALUES ('14', '角色列表权限', null, 'system:role:view');
INSERT INTO `perm` VALUES ('15', '权限列表权限', null, 'system:perm:view');
INSERT INTO `perm` VALUES ('16', '用户增加', null, 'system:user:add');
INSERT INTO `perm` VALUES ('17', '资源列表权限', null, 'system:resource');
