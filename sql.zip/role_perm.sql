/*
Navicat MySQL Data Transfer

Source Server         : leufay
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-04 18:27:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for role_perm
-- ----------------------------
DROP TABLE IF EXISTS `role_perm`;
CREATE TABLE `role_perm` (
  `ROLE_ID` bigint(20) DEFAULT NULL,
  `PERM_ID` bigint(20) DEFAULT NULL,
  KEY `FK_Reference_12` (`PERM_ID`),
  KEY `FK_Reference_13` (`ROLE_ID`),
  CONSTRAINT `FK_Reference_12` FOREIGN KEY (`PERM_ID`) REFERENCES `perm` (`PERM_ID`),
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`ROLE_ID`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_perm
-- ----------------------------
INSERT INTO `role_perm` VALUES ('5', '7');
INSERT INTO `role_perm` VALUES ('5', '11');
INSERT INTO `role_perm` VALUES ('5', '12');
INSERT INTO `role_perm` VALUES ('5', '17');
INSERT INTO `role_perm` VALUES ('3', '13');
INSERT INTO `role_perm` VALUES ('3', '14');
INSERT INTO `role_perm` VALUES ('3', '15');
INSERT INTO `role_perm` VALUES ('6', '11');
